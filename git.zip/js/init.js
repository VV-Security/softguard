(function ($) {
  $(function () {

    $('.sidenav').sidenav();
    $('.parallax').parallax();
    $('.carousel').carousel();

  }); // end of document ready
})(jQuery); // end of jQuery name space
